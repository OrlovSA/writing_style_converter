from .wsc import WSC, WSCEnum
