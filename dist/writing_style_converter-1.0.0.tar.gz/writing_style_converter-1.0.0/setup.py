from setuptools import setup, find_packages

setup(
    name='writing_style_converter',
    version='1.0.0',
    packages=find_packages(),
    author='Stepan Orlov',
    author_email='stepan.nadym@gmail.com',
    description='Telegram @Orlov_SA',
    license="MIT License"
)
